Can be compiled with any C compiler and run in most any environment.
